## Module <sendgrid_email>

#### 30.01.2021
#### Version 15.0.1.0.0
##### ADD
- Initial commit for sendgrid_email.

