SendGrid Email API
==================

This module comes under Odoo Email Marketing.
It will Use for Emailing. It could be use for Bulk
Mailing and Single Mailing . Email Template use for
constructing Email Content.It includes Mail reports
and Bounce Checking Option, here user can Konw the mail status.  

Usage
=====

After the installation,in email marketting settings user can see sendgrid api setting field by ticking in check box a new text field will appear here user can set the API key by saving it key will be save in the system ,in email marketting configuration includes a sub menu sendgrid email template details here user can create email templates . in configuration have another menu called sendgrid from emails this menu is used for creating new from emails for using in malling. in mailing menu create a new mail here user can see a new page view called sendgrid emails here we can set the template and another specifications, using sendgrid button on top user can send the mail.  

Configuration
=============

For saving the API key configuration have check box field sendgrid api by ticking in check box a new text field will appear here user can set the API key by saving it key will be save in the system.


Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developer:
  Noushid Khan.P

Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com

This module is maintained by Cybrosys Technologies.

For support and more information, please visit `Our Website <https://cybrosys.com/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__


